/**
 * Renderiza o formulário para criar uma nova fornecedor.
 * @return {string} HTML do formulário de criação de fornecedor.
 */
function renderizarFormulario() {
  return `
          <form class="mt-3" id="formulario_fornecedor">
              <div class="form-group">
                  <label for="fornecedor_titulo">Nome do fornecedor:</label>
                  <input type="text" class="form-control" id="fornecedor_nome_formulario">
              </div>
              <div class="form-group">
                  <label for="fornecedor_titulo">CNPJ do fornecedor:</label>
                  <input type="text" class="form-control" id="fornecedor_cnpj_formulario">
              </div>
              <div class="form-group">
                  <label for="fornecedor_titulo">Email fornecedor:</label>
                  <input type="text" class="form-control" id="fornecedor_email_formulario">
              </div>
              <div class="form-group">
                  <label for="fornecedor_titulo">WebSite da fornecedor:</label>
                  <input type="text" class="form-control" id="fornecedor_website_formulario">
              </div>
              <button type="submit" class="btn btn-primary mt-2">Salvar</button>
          </form>
      `;
}

/**
 * Renderiza o formulário para atualizar uma fornecedor existente.
 * @param {Object} fornecedor - A fornecedor a ser atualizada.
 * @return {string} HTML do formulário de atualização de fornecedor.
 */
function renderizarFormularioAtualizar(fornecedor) {
    return `
            <form class="mt-3" id="formulario_fornecedor_atualizar">
                <input type="hidden" class="form-control" id="fornecedor_cnpj_formulario" value="${fornecedor.CNPJ}">
                <div class="form-group">
                    <label for="fornecedor_titulo">Nome do fornecedor:</label>
                    <input type="text" class="form-control" id="fornecedor_nome_formulario" value="${fornecedor.NoFornecedor}">
                </div>
                <div class="form-group">
                    <label for="fornecedor_email">Email do fornecedor:</label>
                    <input type="text" class="form-control" id="fornecedor_email_formulario" value="${fornecedor.Email}">
                </div>
                <div class="form-group">
                    <label for="fornecedor_website">Website do fornecedor:</label>
                    <input type="text" class="form-control" id="fornecedor_website_formulario" value="${fornecedor.WebSite}">
                </div>
                <button type="submit" class="btn btn-primary mt-2">Salvar</button>
            </form>
        `;
}

  /**
 * Renderiza a tabela de fornecedors.
 * @param {Array} fornecedors - Lista de fornecedors a serem exibidas.
 * @return {string} HTML da tabela de fornecedors.
 */
function renderizarTabela(fornecedors) {
  let tabela = `
          <table class="table table-striped mt-3">
              <thead>
                  <tr>
                      <th>CNPJ</th>
                      <th>Nome</th>
                      <th>Email</th>
                      <th>WebSite</th>
                      <th>Ações</th> 
                  </tr>
              </thead>
              <tbody>
      `;

  fornecedors.forEach((fornecedor) => {
    tabela += `
              <tr>
                  <td>${fornecedor.CNPJ}</td>
                  <td>${fornecedor.NoFornecedor}</td>
                  <td>${fornecedor.Email}</td>
                  <td>${fornecedor.WebSite}</td>
                  <td>
                    <button class="excluir-btn" fornecedor-id=${fornecedor.CNPJ}>Excluir</button>
                    <button class="atualizar-btn" fornecedor-atualizar-id=${fornecedor.CNPJ}>Atualizar</button>
                  </td>
              </tr>
          `;
  });

  tabela += `
              </tbody>
          </table>
      `;

  return tabela;
}

const FornecedorView = {
    renderizarFormulario,
    renderizarTabela,
    renderizarFormularioAtualizar
};

export default FornecedorView;
