import fornecedorView from "../view/FornecedoresView.js";
import { API_BASE_URL } from "../config/config.js";

/**
 * Renderiza o formulário de fornecedor.
 * @param {HTMLElement} componentePrincipal - Elemento principal onde o formulário será renderizado.
 */
function renderizarFornecedorFormulario(componentePrincipal) {
  componentePrincipal.innerHTML = fornecedorView.renderizarFormulario();
  document.getElementById("formulario_fornecedor").addEventListener("submit", cadastrarFornecedor);
}

/**
 * Cadastra uma nova fornecedor.
 * @param {Event} event - Evento do formulário.
 */
async function cadastrarFornecedor(event) {
  event.preventDefault();
  
  const cnpjValor = document.getElementById("fornecedor_cnpj_formulario").value;
  const nomeValor = document.getElementById("fornecedor_nome_formulario").value;
  const emailValor = document.getElementById("fornecedor_email_formulario").value;
  const websiteValor = document.getElementById("fornecedor_website_formulario").value;

  const novaFornecedor = { cnpj: cnpjValor, nome: nomeValor, email: emailValor, website: websiteValor };

  try {
    await fetch(`${API_BASE_URL}/fornecedores`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(novaFornecedor),
    });
    const componentePrincipal = document.querySelector("#conteudo_principal");
    await renderizarListaFornecedores(componentePrincipal);
  } catch (error) {
    console.error("Erro ao adicionar fornecedor:", error);
  }
}
/**
 * Renderiza a lista de fornecedores.
 * @param {HTMLElement} componentePrincipal - Elemento principal onde a lista será renderizada.
 */
async function renderizarListaFornecedores(componentePrincipal) {
  try {
    const response = await fetch(API_BASE_URL + "/fornecedores");
    const fornecedoresBD = await response.json(); 

    const fornecedores = fornecedoresBD.map((row) => {
      return {
        CNPJ: row.CNPJ,
        NoFornecedor: row.NoFornecedor,
        Email: row.Email,
        WebSite: row.WebSite
      };
    });
    componentePrincipal.innerHTML = fornecedorView.renderizarTabela(fornecedores);
    inserirEventosExcluir();
    inserirEventosAtualizar();
  } catch (error) {
    console.error("Erro ao buscar fornecedores:", error);
  }
}

/**
 * Adiciona eventos de clique aos botões de exclusão de fornecedor.
 * Cada botão, quando clicado, aciona a função de exclusão de fornecedor correspondente.
 */
function inserirEventosExcluir() {
  const botoesExcluir = document.querySelectorAll(".excluir-btn");
  botoesExcluir.forEach((botao) => {
    botao.addEventListener("click", function () {
      const fornecedorId = this.getAttribute("fornecedor-id");
      excluirFornecedor(fornecedorId);
    });
  });
}

/**
 * Adiciona eventos de clique aos botões de atualização de fornecedor.
 * Cada botão, quando clicado, aciona a função de buscar a fornecedor específica para atualização.
 */
function inserirEventosAtualizar() {
  const botoesAtualizar = document.querySelectorAll(".atualizar-btn");
  botoesAtualizar.forEach((botao) => {
    botao.addEventListener("click", function () {
      const fornecedorId = this.getAttribute("fornecedor-atualizar-id");
      buscarFornecedor(fornecedorId);
    });
  });
}

/**
 * Exclui uma fornecedor específica com base no ID.
 * Após a exclusão bem-sucedida, a lista de fornecedores é atualizada.
 * @param {string} id - ID da fornecedor a ser excluída.
 */
async function excluirFornecedor(id) {
  try {
    const response = await fetch(`${API_BASE_URL}/fornecedores/${id}`, { method: "DELETE" });
    if (!response.ok) throw new Error("Erro ao excluir a fornecedor");
    const componentePrincipal = document.querySelector("#conteudo_principal");
    renderizarListaFornecedores(componentePrincipal);
  } catch (error) {
    console.error("Erro ao excluir a fornecedor:", error);
  }
}

/**
 * Busca uma fornecedor específica para atualização, com base no ID.
 * Após encontrar a fornecedor, renderiza o formulário de atualização.
 * @param {string} id - ID da fornecedor a ser buscada.
 */
async function buscarFornecedor(id) {
  try {
    const response = await fetch(`${API_BASE_URL}/fornecedores/${id}`);
    const fornecedoresBD = await response.json();
    if (fornecedoresBD.length <= 0) return;

    const fornecedor = fornecedoresBD.map(row => ({
      CNPJ: row.CNPJ,
      NoFornecedor: row.NoFornecedor,
      Email: row.Email,
      WebSite: row.WebSite
    }))[0];

    const componentePrincipal = document.querySelector("#conteudo_principal");
    componentePrincipal.innerHTML = fornecedorView.renderizarFormularioAtualizar(fornecedor);
    document.getElementById("formulario_fornecedor_atualizar").addEventListener("submit", atualizarFornecedor);
  } catch (error) {
    console.error("Erro ao buscar fornecedores:", error);
  }
}

/**
 * Atualiza uma fornecedor específica.
 * A função é acionada pelo evento de submit do formulário de atualização.
 * @param {Event} event - O evento de submit do formulário.
 */
async function atualizarFornecedor(event) {
  event.preventDefault();

  const cnpjValor = document.getElementById("fornecedor_cnpj_formulario").value;
  const nomeValor = document.getElementById("fornecedor_nome_formulario").value;
  const emailValor = document.getElementById("fornecedor_email_formulario").value;
  const websiteValor = document.getElementById("fornecedor_website_formulario").value;

  const fornecedor = { cnpj: cnpjValor, nome: nomeValor, email: emailValor, website: websiteValor };

  try {
    const response = await fetch(`${API_BASE_URL}/fornecedores`, {
      method: "PUT",
      headers: {"Content-Type": "application/json",},
      body: JSON.stringify(fornecedor),
    });

    if (!response.ok) {
      throw new Error("Falha ao atualizar a fornecedor");
    }
    const componentePrincipal = document.querySelector("#conteudo_principal");
    renderizarListaFornecedores(componentePrincipal);
  } catch (error) {
    console.error("Erro ao atualizar fornecedor:", error);
  }
}

const FornecedorController = {
  renderizarFornecedorFormulario,
  cadastrarFornecedor,
  renderizarListaFornecedores,
  excluirFornecedor,
};

export default FornecedorController;
