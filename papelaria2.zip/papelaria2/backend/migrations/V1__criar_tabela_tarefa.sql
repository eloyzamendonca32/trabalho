-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 08/11/2023 às 02:10
-- Versão do servidor: 10.4.28-MariaDB
-- Versão do PHP: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `dbpapelaria`
--

-- --------------------------------------------------------

--
-- Estrutura para tabela `tbavaliacao`
--

CREATE TABLE `tbavaliacao` (
  `IdAvaliação` int(11) NOT NULL,
  `QtEstrelas` int(11) NOT NULL,
  `IdProduto` int(11) NOT NULL,
  `IdCliente` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `tbavaliacao`
--

INSERT INTO `tbavaliacao` (`IdAvaliação`, `QtEstrelas`, `IdProduto`, `IdCliente`) VALUES
(1, 5, 1, 1),
(2, 4, 2, 2),
(3, 5, 3, 3),
(4, 3, 4, 4),
(5, 4, 5, 5),
(6, 2, 6, 6),
(7, 5, 7, 7);

-- --------------------------------------------------------

--
-- Estrutura para tabela `tbcategoria`
--

CREATE TABLE `tbcategoria` (
  `IdCategoria` int(11) NOT NULL,
  `NoCategoria` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `tbcategoria`
--

INSERT INTO `tbcategoria` (`IdCategoria`, `NoCategoria`) VALUES
(1, 'Canetas'),
(2, 'Papéis'),
(3, 'Material de escritório'),
(4, 'Material de desenho'),
(5, 'Suprimentos de papelaria');

-- --------------------------------------------------------

--
-- Estrutura para tabela `tbcliente`
--

CREATE TABLE `tbcliente` (
  `IdCliente` int(11) NOT NULL,
  `NoCliente` varchar(100) NOT NULL,
  `Telefone` varchar(20) NOT NULL,
  `Endereço` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `tbcliente`
--

INSERT INTO `tbcliente` (`IdCliente`, `NoCliente`, `Telefone`, `Endereço`) VALUES
(1, 'Maria Silva', '(11) 91234-5678', 'Rua das Flores, 123'),
(2, 'João Santos', '(22) 99876-5432', 'Avenida Principal, 456'),
(3, 'Ana Pereira', '(33) 95555-9999', 'Rua da Praia, 789'),
(4, 'Carlos Mendes', '(44) 91111-2222', 'Travessa das Árvores, 654'),
(5, 'Lúcia Rodrigues', '(55) 98888-7777', 'Avenida Central, 987'),
(6, 'Paulo Fernandes', '(66) 93333-4444', 'Rua dos Comerciantes, 321'),
(7, 'Cristina Alves', '(77) 99999-0000', 'Alameda das Lojas, 987');

-- --------------------------------------------------------

--
-- Estrutura para tabela `tbfornecedor`
--

CREATE TABLE `tbfornecedor` (
  `CNPJ` varchar(14) NOT NULL,
  `NoFornecedor` varchar(100) NOT NULL,
  `Email` varchar(100) NOT NULL,
  `WebSite` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `tbfornecedor`
--

INSERT INTO `tbfornecedor` (`CNPJ`, `NoFornecedor`, `Email`, `WebSite`) VALUES
('1234567890001', 'Fornecedor A', 'fornecedor1@example.com', 'www.fornecedora.com'),
('4567890120004', 'Fornecedor D', 'fornecedor4@example.com', 'www.fornecedord.com'),
('5678901230003', 'Fornecedor C', 'fornecedor3@example.com', 'www.fornecedorc.com'),
('9876543210002', 'Fornecedor B', 'fornecedor2@example.com', 'www.fornecedorb.com');

-- --------------------------------------------------------

--
-- Estrutura para tabela `tbproduto`
--

CREATE TABLE `tbproduto` (
  `IdProduto` int(10) NOT NULL,
  `IDCategoria` int(11) NOT NULL,
  `CNPJ` varchar(14) NOT NULL,
  `NoProduto` varchar(100) NOT NULL,
  `VaProduto` decimal(10,2) NOT NULL,
  `QtEstoque` int(11) NOT NULL,
  `UniMedida` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `tbproduto`
--

INSERT INTO `tbproduto` (`IdProduto`, `IDCategoria`, `CNPJ`, `NoProduto`, `VaProduto`, `QtEstoque`, `UniMedida`) VALUES
(1, 1, '1234567890001', 'Caneta Esferográfica', 1.50, 500, 'Unidade'),
(2, 2, '9876543210002', 'Caderno Universitário', 10.99, 200, 'Unidade'),
(3, 2, '5678901230003', 'Papel Sulfite A4', 19.99, 1000, 'Resma'),
(4, 3, '4567890120004', 'Lápis HB', 5.50, 1000, 'Caixa'),
(5, 3, '1234567890001', 'Borracha', 0.99, 800, 'Unidade'),
(6, 3, '5678901230003', 'Marcadores de Texto', 8.75, 300, 'Caixa'),
(7, 3, '1234567890001', 'Clips Metálicos', 2.25, 1500, 'Caixa'),
(8, 3, '9876543210002', 'Tesoura Escolar', 3.99, 400, 'Unidade'),
(9, 3, '5678901230003', 'Apontador de Lápis', 1.25, 600, 'Unidade'),
(10, 3, '4567890120004', 'Envelopes Ofício', 12.50, 900, 'Caixa');

-- --------------------------------------------------------

--
-- Estrutura para tabela `tbprodutovenda`
--

CREATE TABLE `tbprodutovenda` (
  `IdProdutoVenda` int(11) NOT NULL,
  `IdVenda` int(11) NOT NULL,
  `IdProduto` int(11) NOT NULL,
  `QtVendida` int(11) NOT NULL,
  `VaVenda` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `tbprodutovenda`
--

INSERT INTO `tbprodutovenda` (`IdProdutoVenda`, `IdVenda`, `IdProduto`, `QtVendida`, `VaVenda`) VALUES
(1, 1, 1, 10, 50.00),
(2, 2, 2, 5, 25.00),
(3, 3, 3, 8, 40.00),
(4, 4, 4, 12, 60.00),
(5, 5, 5, 15, 75.00);

-- --------------------------------------------------------

--
-- Estrutura para tabela `tbvenda`
--

CREATE TABLE `tbvenda` (
  `IdVenda` int(11) NOT NULL,
  `DaVenda` date NOT NULL,
  `IdCliente` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `tbvenda`
--

INSERT INTO `tbvenda` (`IdVenda`, `DaVenda`, `IdCliente`) VALUES
(1, '2023-11-01', 1),
(2, '2023-11-02', 2),
(3, '2023-11-03', 3),
(4, '2023-11-04', 4),
(5, '2023-11-05', 5);

--
-- Índices para tabelas despejadas
--

--
-- Índices de tabela `tbavaliacao`
--
ALTER TABLE `tbavaliacao`
  ADD PRIMARY KEY (`IdAvaliação`),
  ADD KEY `tbAvaliacao_fk0` (`IdProduto`),
  ADD KEY `tbAvaliacao_fk1` (`IdCliente`);

--
-- Índices de tabela `tbcategoria`
--
ALTER TABLE `tbcategoria`
  ADD PRIMARY KEY (`IdCategoria`);

--
-- Índices de tabela `tbcliente`
--
ALTER TABLE `tbcliente`
  ADD PRIMARY KEY (`IdCliente`);

--
-- Índices de tabela `tbfornecedor`
--
ALTER TABLE `tbfornecedor`
  ADD PRIMARY KEY (`CNPJ`);

--
-- Índices de tabela `tbproduto`
--
ALTER TABLE `tbproduto`
  ADD PRIMARY KEY (`IdProduto`),
  ADD KEY `tbProduto_fk0` (`IDCategoria`),
  ADD KEY `tbProduto_fk1` (`CNPJ`);

--
-- Índices de tabela `tbprodutovenda`
--
ALTER TABLE `tbprodutovenda`
  ADD PRIMARY KEY (`IdProdutoVenda`),
  ADD KEY `tbProdutoVenda_fk0` (`IdVenda`),
  ADD KEY `tbProdutoVenda_fk1` (`IdProduto`);

--
-- Índices de tabela `tbvenda`
--
ALTER TABLE `tbvenda`
  ADD PRIMARY KEY (`IdVenda`),
  ADD KEY `tbVenda_fk0` (`IdCliente`);

--
-- AUTO_INCREMENT para tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `tbavaliacao`
--
ALTER TABLE `tbavaliacao`
  MODIFY `IdAvaliação` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT de tabela `tbcategoria`
--
ALTER TABLE `tbcategoria`
  MODIFY `IdCategoria` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de tabela `tbcliente`
--
ALTER TABLE `tbcliente`
  MODIFY `IdCliente` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT de tabela `tbproduto`
--
ALTER TABLE `tbproduto`
  MODIFY `IdProduto` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT de tabela `tbprodutovenda`
--
ALTER TABLE `tbprodutovenda`
  MODIFY `IdProdutoVenda` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de tabela `tbvenda`
--
ALTER TABLE `tbvenda`
  MODIFY `IdVenda` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- Restrições para tabelas despejadas
--

--
-- Restrições para tabelas `tbavaliacao`
--
ALTER TABLE `tbavaliacao`
  ADD CONSTRAINT `tbAvaliacao_fk0` FOREIGN KEY (`IdProduto`) REFERENCES `tbproduto` (`IdProduto`),
  ADD CONSTRAINT `tbAvaliacao_fk1` FOREIGN KEY (`IdCliente`) REFERENCES `tbcliente` (`IdCliente`);

--
-- Restrições para tabelas `tbproduto`
--
ALTER TABLE `tbproduto`
  ADD CONSTRAINT `tbProduto_fk0` FOREIGN KEY (`IDCategoria`) REFERENCES `tbcategoria` (`IdCategoria`),
  ADD CONSTRAINT `tbProduto_fk1` FOREIGN KEY (`CNPJ`) REFERENCES `tbfornecedor` (`CNPJ`);

--
-- Restrições para tabelas `tbprodutovenda`
--
ALTER TABLE `tbprodutovenda`
  ADD CONSTRAINT `tbProdutoVenda_fk0` FOREIGN KEY (`IdVenda`) REFERENCES `tbvenda` (`IdVenda`),
  ADD CONSTRAINT `tbProdutoVenda_fk1` FOREIGN KEY (`IdProduto`) REFERENCES `tbproduto` (`IdProduto`);

--
-- Restrições para tabelas `tbvenda`
--
ALTER TABLE `tbvenda`
  ADD CONSTRAINT `tbVenda_fk0` FOREIGN KEY (`IdCliente`) REFERENCES `tbcliente` (`IdCliente`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
create table tarefa (
 	id int PRIMARY KEY AUTO_INCREMENT,
    titulo varchar(300) not null,
    descricao varchar(600)
);