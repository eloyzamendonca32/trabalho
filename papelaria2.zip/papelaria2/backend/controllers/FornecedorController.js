const express = require('express');
const router = express.Router();
const db = require('../util/db');
const verificarToken = require('../util/VerificaToken');

/**
 * Executa uma consulta no banco de dados e envia uma resposta.
 * @param {string} sql - A consulta SQL a ser executada.
 * @param {Array} params - Os parâmetros para a consulta SQL.
 * @param {Object} res - O objeto de resposta do Express.
 * @param {string} erroMsg - Mensagem de erro para ser enviada em caso de falha.
 */
function executarConsulta(sql, params, res, erroMsg) {
  db.query(sql, params, (err, result) => {
    if (err) {
      res.status(500).json({ erro: erroMsg, detalhes: err });
    } else {
      res.status(200).json(result);
    }
  });
}

// Rota para buscar todas as fornecedores
router.get('/', (req, res) => {
  executarConsulta('SELECT * FROM tbfornecedor', [], res, "Erro na consulta de fornecedores");
});

// Rota para buscar uma fornecedor específica
router.get("/:cnpj", (req, res) => {
  const cnpj = req.params.cnpj;
  executarConsulta('SELECT * FROM tbfornecedor WHERE CNPJ = ?', [cnpj], res, "Erro na consulta de fornecedor");
});

// Rota para criar uma nova fornecedor
router.post('/', (req, res) => {
  const { nome, cnpj, email, website } = req.body;
  executarConsulta('INSERT INTO tbfornecedor (NoFornecedor, CNPJ, Email, WebSite) VALUES (?, ?, ?, ?);', [nome, cnpj, email, website], res, "Erro no cadastro de fornecedor!");
});

// Rota para deletar uma fornecedor
router.delete("/:cnpj", (req, res) => {
  const tarefaId = req.params.cnpj;
  executarConsulta('DELETE FROM tbfornecedor WHERE CNPJ = ?', [tarefaId], res, 'Erro ao deletar fornecedor');
});

// Rota para atualizar uma fornecedor
router.put('/', (req, res) => {
  const { cnpj, nome, email, website } = req.body;
  executarConsulta('UPDATE tbfornecedor SET NoFornecedor = ?, Email = ?, WebSite = ? WHERE CNPJ = ?', [nome, email, website, cnpj], res, "Erro ao atualizar fornecedor");
});

module.exports = router;